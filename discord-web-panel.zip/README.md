Discord Web Panel (separate project)

- Host this on Railway, Render, Fly.io, or a VPS (DO NOT host on FPS.ms).
- This project is the admin panel: view tickets, bans, warnings and perform actions.

Quickstart:
1. Copy .env.example -> .env and set credentials and SESSION_SECRET.
2. npm install && npm start
3. Open the app URL and login with WEB_ADMIN_USER / WEB_ADMIN_PASS
